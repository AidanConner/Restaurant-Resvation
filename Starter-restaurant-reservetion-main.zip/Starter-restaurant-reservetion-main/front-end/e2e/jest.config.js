module.exports = {
  preset: "jest-puppeteer",
  testTimeout: 20000,
};
